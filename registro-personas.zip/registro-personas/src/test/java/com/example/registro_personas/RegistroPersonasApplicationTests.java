package com.example.registro_personas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistroPersonasApplicationTests {

	@Test
	void contextLoads() {
	}

}
